from .gradio_app import main

__all__ = ["main"]